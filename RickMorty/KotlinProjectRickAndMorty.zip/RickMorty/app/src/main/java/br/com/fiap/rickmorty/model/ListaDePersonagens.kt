package br.com.fiap.rickmorty.model

data class ListaDePersonagens(
    var results: List <Personagem>
)
