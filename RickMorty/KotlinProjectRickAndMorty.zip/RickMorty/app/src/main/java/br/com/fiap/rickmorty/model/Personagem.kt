package br.com.fiap.rickmorty.model

data class Personagem(
    var id: Int = 0,
    var name: String = "",
    var species: String = "",
    var image: String = ""
)
